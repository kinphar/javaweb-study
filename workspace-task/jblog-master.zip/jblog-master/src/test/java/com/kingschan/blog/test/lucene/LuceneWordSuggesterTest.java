package com.kingschan.blog.test.lucene;

/**
 * Created by kingschan on 2017/3/9.
 */
public class LuceneWordSuggesterTest {

    public static void main(String[] args) {
    }
}

package com.kingschan.blog.model.dto;

import com.kingschan.blog.model.vo.ArticleVo;

/**
 * Created by kingschan on 2017/2/22.
 */
public class ArticleDto {

    private ArticleVo articleVo;
}

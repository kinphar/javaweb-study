package com.kingschan.blog.common.enums;
/**
 * 
*    
* 类名称：BLOG_MODEL   
* 类描述：   博客模式，前端和后台
* 创建人：kings.chan
* 创建时间：2016-7-25 下午3:17:44   
* 修改人：   
* 修改时间：
* 项目：ROOT
* 修改备注：   
* @version    
*
 */
public enum BLOG_MODEL {
	FONT_MODEL,ADMIN_MODEL
}

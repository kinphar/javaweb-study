package com.kingschan.blog.common.enums;
/**
 * 
*    
* 类名称：UserLevel   
* 类描述：   用户级别
* 创建人：kings.chan
* 创建时间：2016-8-9 上午9:24:32   
* 修改人：   
* 修改时间：
* 项目：ROOT
* 修改备注：   
* @version    
*
 */
public enum UserLevel {
		ADMIN,GUEST,ROOT
}

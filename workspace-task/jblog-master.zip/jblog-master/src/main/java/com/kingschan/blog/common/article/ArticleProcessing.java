package com.kingschan.blog.common.article;

/**
 * Created by kingschan on 2017/2/22.
 */
public interface ArticleProcessing {

}

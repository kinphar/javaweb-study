package com.kingschan.blog.services.impl;

import com.kingschan.blog.dao.Pagination;
import com.kingschan.blog.services.ArticleCommentService;

public class ArticleCommentServiceImpl implements ArticleCommentService{

	@Override
	public Pagination getSupportUsersByCommentId(String id) throws Exception {
		return null;
	}

}

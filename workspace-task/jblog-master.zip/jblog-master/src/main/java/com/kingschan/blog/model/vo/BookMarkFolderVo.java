package com.kingschan.blog.model.vo;


public class BookMarkFolderVo {
	
    private Integer id;
    private String bookmarksName;
    private String bookmarksRemark;
    
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getBookmarksName() {
        return bookmarksName;
    }
    public void setBookmarksName(String bookmarksName) {
        this.bookmarksName = bookmarksName;
    }
	public String getBookmarksRemark() {
		return bookmarksRemark;
	}
	public void setBookmarksRemark(String bookmarksRemark) {
		this.bookmarksRemark = bookmarksRemark;
	}
    
    
    
}
